package com.sysdes.movie_movie_streaming_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieMovieStreamingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
